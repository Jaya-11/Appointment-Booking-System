export const mainCategory = [
  { id: 1, label: 'Beauty' },
  { id: 2, label: 'Health & fitness' },
  { id: 3, label: 'Medical' },
  { id: 4, label: 'Education' },
  { id: 5, label: 'Household' },
];
